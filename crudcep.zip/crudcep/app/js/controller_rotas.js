
var app = angular.module('myApp', ['angularUtils.directives.dirPagination']);

app.controller('customersRotas', function ($scope, $http) {

    $scope.enabled = [];


    $scope.rotassalvas = function (){


        $http.post("../src/rotassalvas.rest.php")
        .then(function (response) {
            $scope.rotassalvas = response.data;
           // console.log($scope.rotassalvas);

  
        }).catch(function (err) {
            bootbox.alert('<font color= "red"><i class="fa fa-bug" aria-hidden="true"></i> Problemas no SQL!! ');
            window.setTimeout(function () {
                bootbox.hideAll();
            }, 2000);
        })
        .finally(function () {
        });


    }

    $scope.rotassalvas();



$scope.salvarrota =function (buscacep1cep,buscacep1logradouro,buscacep1bairro,buscacep1localidade,buscacep1uf,buscacep2cep,buscacep2logradouro,buscacep2bairro,buscacep2localidade,buscacep2uf,km){

var cepini = buscacep1cep  ;
var logradouroini = buscacep1logradouro  ;
var bairroini =  buscacep1bairro ;
var localidadeini =  buscacep1localidade ;
var ufini =  buscacep1uf ;
var cepfim = buscacep2cep  ;
var logradourofim = buscacep2logradouro  ;
var bairrofim =  buscacep2bairro ;
var localidadefim = buscacep2localidade  ;
var uffim = buscacep2uf;
var distancia = km;


console.log(distancia);


if(cepini != null && distancia != null){

   var data = { cepini, logradouroini,bairroini,localidadeini , ufini,cepfim,logradourofim,bairrofim,localidadefim,uffim,distancia};
 
    $http.post("../src/insert_rota.rest.php", data)
        .then(function (response) {
            $scope.salvarrota = response.data;
            console.log($scope.salvarrota);

            bootbox.alert('<font color= "green"><i class="fa fa-check-square-o" aria-hidden="true"></i> Salvo com sucesso!! ');
            window.setTimeout(function () {
                bootbox.hideAll();
                window.location = '../app/index.html';
            }, 2000)
          
  
        }).catch(function (err) {
            bootbox.alert('<font color= "red"><i class="fa fa-bug" aria-hidden="true"></i> Problemas na insercao!! ');
            window.setTimeout(function () {
                bootbox.hideAll();
            }, 2000);
        })
        .finally(function () {

           
        });

    }else{
        bootbox.alert('<font color= "red"><i class="fa fa-bug" aria-hidden="true"></i> Campos obrigatórios!! ');
        window.setTimeout(function () {
            bootbox.hideAll();
        }, 2000);


    }
}

   $scope.buscacep1 = function () {
$scope.loading = true;
    var codcep = $scope.cep;
    //console.log(codcep);
    var data = {codcep};

    $http.post("../src/cep1.rest.php", data)
        .then(function (response) {
            $scope.buscacep1 = response.data;
           // console.log($scope.buscacep1);

            if($scope.buscacep1.erro === true){
                bootbox.alert('<font color= "red"><i class="fa fa-bug" aria-hidden="true"></i> Cep Inicio não encontrado!! ');
                window.setTimeout(function () {
                    bootbox.hideAll();
                }, 2000);

            }
        }).catch(function (err) {
            bootbox.alert('<font color= "red"><i class="fa fa-bug" aria-hidden="true"></i> Cep Inicio não encontrado!! ');
            window.setTimeout(function () {
                bootbox.hideAll();
            }, 2000);
        })
        .finally(function () {

            $scope.loading = false;
            
           
        });

}


$scope.buscacep2 = function () {

    $scope.loading = true;
    var codcep = $scope.cep2;
    //console.log(codcep);
    var data = {codcep};
    $http.post("../src/cep2.rest.php", data)
       .then(function (response) {
            $scope.buscacep2 = response.data;
            //console.log($scope.buscacep);

            if($scope.buscacep2.erro === true){
                bootbox.alert('<font color= "red"><i class="fa fa-bug" aria-hidden="true"></i> Cep Rota Final não encontrado!! ');
                window.setTimeout(function () {
                    bootbox.hideAll();
                }, 2000);

            }

        }).catch(function (err) {
            bootbox.alert('<font color= "red"><i class="fa fa-bug" aria-hidden="true"></i> Cep Destino não encontrado!! ');
            window.setTimeout(function () {
                bootbox.hideAll();
            }, 2000);
        })
        .finally(function () {
            $scope.loading = false;

        });

}


$scope.distancia = function (){

    var latitude1 = $scope.buscacep1.latitude;
    var latitude2 = $scope.buscacep2.latitude;
    var longitude1 = $scope.buscacep1.longitude;
    var longitude2 = $scope.buscacep2.longitude;        

    data = {latitude1,latitude2,longitude1,longitude2};
    console.log(data);

    $http.post("../src/distancia.rest.php",data)
    .then(function (response) {
        $scope.resultdist = response.data;
        console.log($scope.resultdist);

        $scope.kilometros = $scope.resultdist;


    }).catch(function (err) {
        bootbox.alert('<font color= "red"><i class="fa fa-bug" aria-hidden="true"></i> Problemas no SQL!! ');
        window.setTimeout(function () {
            bootbox.hideAll();
        }, 2000);
    })
    .finally(function () {
    });



}


$scope.excluir = function (codigo) {


    bootbox.confirm({
        message: "<font color='red'>Deseja realmente excluir a rota?</font>",
        buttons: {
            confirm: {
                label: 'Sim',
                className: 'btn-primary'
            },
            cancel: {
                label: 'Não',
                className: 'btn-danger'
            }
        },
        callback: function (result) {
            console.log('Deseja realmente excluir a rota? ' + result);
            if (result == true) {
                var idcord = codigo;
                var data = { idcord };

                window.location = '../app/index.html';

                $http.post("../src/excluir.rest.php", data)
                    .then(function (response) {
                        $scope.result_rota = response.data;
                        //console.log($scope.result_rota);
                        bootbox.alert('<font color= "green"><i class="fa fa-bug" aria-hidden="true"></i> Rota excluida com sucesso!! ');
                        window.setTimeout(function () {
                            bootbox.hideAll();
                        }, 2000);
                       
                    });
             
            }
        }
    });
    
}

	// liberar input para editar
	$scope.editar = function(x) {
		console.log("index: " + x);
		$scope.enabled[x] = true;
	}


    // function update
	$scope.alterar = function (idcord,cepini,cepfim,kmini) {
		
		
		var data = {idcord,cepini,cepfim,kmini};
		//console.log(data);
	    var campo1 = '';
		var campo2 = '';
		var campo3 = '';

		if(cepini == '' ){ var campo1 = 'Cep não Inicial preenchido'}
		if(cepfim == '' ){var campo2 = 'Cep não Final preenchido'}
		if(kmini == '' ){var campo3 = 'kilometros não preenchidos'}

		if(cepini != '' && cepfim != '' && kmini != '' ){

		$http.post("../src/alterar_rota.php", data

		).then(
			function (response) {
				$scope.rtrnUsers = response.data;
                //console.log($scope.rtrnUsers );
				bootbox.alert('<font color= "green"><i class="fa fa-check-square-o" aria-hidden="true"> Salvo com sucesso!!</font>');
				window.setTimeout(function(){
					
					bootbox.hideAll();
					//window.location = "../app/update_gondolas.html";
				}, 1000);
				
			}
		);
			
	
		} else {
			bootbox.alert('<font color= "red"> Favor preencher o campo : <font>'+ campo1 + ' ' + campo2 + ' ' + campo3  );
			window.setTimeout(function(){
					
				bootbox.hideAll();
			}, 2000);
		}
	}

});

<?php
require_once('../../conn/conexao.php');
date_default_timezone_set('America/Sao_Paulo');
$inputs = json_decode( file_get_contents('php://input'), true);


$sql = 'UPDATE coordenadas SET cepini = :cepini, cepfim = :cepfim, kmini = :kmini
WHERE idcord = :idcord;';
$conexao = conexao::getInstance();
$stm = $conexao->prepare($sql);
$stm->bindValue(':cepini', $inputs['cepini']);
$stm->bindValue(':cepfim', $inputs['cepfim']);
$stm->bindValue(':kmini',  $inputs['kmini']);
$stm->bindValue(':idcord',  $inputs['idcord']);
$retorno = $stm->execute();
print_r($retorno);
?>
<?php

$inputs = json_decode( file_get_contents('php://input'), true);

// function cep($cep) {
//     $cep=preg_replace('/[^0-9]/', '', (string) $cep);
//     $url = "http://viacep.com.br/ws/".$cep."/json/";
//     $ch = curl_init();
//     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//     curl_setopt($ch, CURLOPT_URL, $url);
//     $result = curl_exec($ch);
//     curl_close($ch);
//     return $result;
//     }
//     print_r(cep($inputs['codcep']));

$cep = $inputs['codcep'];

    function enviaConteudoParaAPI($cabecalho = array(), $conteudoAEnviar, $url, $tpRequisicao) {
        try{
         $ch = curl_init($url);
            if ($tpRequisicao == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $conteudoAEnviar);
            }
            if (!empty($cabecalho)) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $cabecalho);
            }
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $resposta = curl_exec($ch);
            curl_close($ch);
        }catch(Exception $e){
            return $e->getMessage();
        }
        return $resposta;
    }
    $header = array(
        'Content-Type: application/json',
        'Authorization: Token token=206fa39189681d712f955137665dc157'
    );
    sleep(2);
    print_r(enviaConteudoParaAPI($header,'', 'https://www.cepaberto.com/api/v3/cep?cep='.$cep,'GET'));

?>
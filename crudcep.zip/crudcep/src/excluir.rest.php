<?php
require_once('../../conn/conexao.php');
//require_once('../../conn/commons.inc.php');
date_default_timezone_set('America/Sao_Paulo');
$inputs = json_decode( file_get_contents('php://input'), true);


$conexao = conexao::getInstance();
$sql = "DELETE  FROM coordenadas WHERE idcord = :idcord ";
$stm = $conexao->prepare($sql);
$stm->bindValue(':idcord', $inputs['idcord']);
$stm->execute();
$result_excluir = $stm->fetchAll(PDO::FETCH_OBJ);


print_r(json_encode($result_excluir));


?>
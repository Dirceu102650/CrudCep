<?php
require_once('../../conn/conexao.php');
date_default_timezone_set('America/Sao_Paulo');
$inputs = json_decode( file_get_contents('php://input'), true);

//print_r($inputs); die;

$sql = 'INSERT INTO coordenadas (cepini, logradouroini,bairroini,localidadeini , ufini,cepfim,logradourofim,bairrofim,localidadefim,uffim,kmini,datacadastro)
VALUES(:cepini, :logradouroini,:bairroini,:localidadeini , :ufini,:cepfim,:logradourofim,:bairrofim,:localidadefim,:uffim,:kmini, NOW())';
$conexao = conexao::getInstance();
$stm = $conexao->prepare($sql);
$stm->bindValue(':cepini', $inputs['cepini']);
$stm->bindValue(':logradouroini', $inputs['logradouroini']);
$stm->bindValue(':bairroini',  $inputs['bairroini']);
$stm->bindValue(':localidadeini',  $inputs['localidadeini']);
$stm->bindValue(':ufini',  $inputs['ufini']);
$stm->bindValue(':cepfim', $inputs['cepfim']);
$stm->bindValue(':logradourofim', $inputs['logradourofim']);
$stm->bindValue(':bairrofim',  $inputs['bairrofim']);
$stm->bindValue(':localidadefim',  $inputs['localidadefim']);
$stm->bindValue(':uffim',  $inputs['uffim']);
$stm->bindValue(':kmini',  $inputs['distancia']);
$retorno = $stm->execute();
print_r($retorno);
?>
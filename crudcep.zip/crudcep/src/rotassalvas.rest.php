<?php
require_once('../../conn/conexao.php');

date_default_timezone_set('America/Sao_Paulo');

$conexao = conexao::getInstance();
$sql = 'SELECT kmini,idcord, cepini, logradouroini,bairroini,localidadeini , ufini,cepfim,logradourofim,bairrofim,localidadefim,uffim, DATE_FORMAT(datacadastro,"%d/%m/%Y %h:%i:%s") as datacadastro FROM coordenadas ';
$stm = $conexao->prepare($sql);
$stm->execute();
$result_rotas = $stm->fetchAll(PDO::FETCH_OBJ);

print_r(json_encode($result_rotas));


?>